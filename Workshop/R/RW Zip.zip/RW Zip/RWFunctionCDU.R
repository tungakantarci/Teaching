# R Workshop - Function File - Cobb Douglas Utility

RWFunctionCDU = function(X) 
{
x1 = X[1]
x2 = X[2]
-(x1^0.5)*(x2^0.5)
}
